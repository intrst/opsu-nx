#include "opsu/util/MD5.h"
#include <cstring>

namespace opsu {

namespace {
inline uint32_t rotl(uint32_t x, int c) { return (x << c) | (x >> (32 - c)); }

const uint32_t K[64] = {
    0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee, 0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501,
    0x698098d8, 0x8b44f7af, 0xffff5bb1, 0x895cd7be, 0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821,
    0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa, 0xd62f105d, 0x02441453, 0xd8a1e681, 0xe7d3fbc8,
    0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed, 0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a,
    0xfffa3942, 0x8771f681, 0x6d9d6122, 0xfde5380c, 0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70,
    0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05, 0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665,
    0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039, 0x655b59c3, 0x8f0ccc92, 0xffeff47d, 0x85845dd1,
    0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1, 0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391};

const int S[64] = {7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
                   5, 9,  14, 20, 5, 9,  14, 20, 5, 9,  14, 20, 5, 9,  14, 20,
                   4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23,
                   6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21};
}  // namespace

MD5::MD5() { reset(); }

void MD5::reset() {
    state[0] = 0x67452301;
    state[1] = 0xefcdab89;
    state[2] = 0x98badcfe;
    state[3] = 0x10325476;
    totalBytes = 0;
    std::memset(buffer, 0, sizeof buffer);
}

void MD5::transform(const uint8_t block[64]) {
    uint32_t M[16];
    for (int i = 0; i < 16; i++)
        M[i] = (uint32_t)block[i * 4] | ((uint32_t)block[i * 4 + 1] << 8) |
               ((uint32_t)block[i * 4 + 2] << 16) | ((uint32_t)block[i * 4 + 3] << 24);
    uint32_t a = state[0], b = state[1], c = state[2], d = state[3];
    for (int i = 0; i < 64; i++) {
        uint32_t f;
        int g;
        if (i < 16)      { f = (b & c) | (~b & d); g = i; }
        else if (i < 32) { f = (d & b) | (~d & c); g = (5 * i + 1) & 15; }
        else if (i < 48) { f = b ^ c ^ d;          g = (3 * i + 5) & 15; }
        else             { f = c ^ (b | ~d);       g = (7 * i) & 15; }
        uint32_t tmp = d;
        d = c;
        c = b;
        b = b + rotl(a + f + K[i] + M[g], S[i]);
        a = tmp;
    }
    state[0] += a; state[1] += b; state[2] += c; state[3] += d;
}

void MD5::update(const uint8_t* data, std::size_t len) {
    std::size_t fill = (std::size_t)(totalBytes & 63);
    totalBytes += len;
    if (fill) {
        std::size_t take = 64 - fill < len ? 64 - fill : len;
        std::memcpy(buffer + fill, data, take);
        data += take;
        len -= take;
        if (fill + take < 64) return;
        transform(buffer);
    }
    while (len >= 64) {
        transform(data);
        data += 64;
        len -= 64;
    }
    if (len) std::memcpy(buffer, data, len);
}

std::array<uint8_t, 16> MD5::digest() {
    const uint64_t bits = totalBytes * 8;
    uint8_t pad[72] = {0x80};
    std::size_t padLen = (std::size_t)((totalBytes & 63) < 56 ? 56 - (totalBytes & 63) : 120 - (totalBytes & 63));
    for (int i = 0; i < 8; i++) pad[padLen + i] = (uint8_t)(bits >> (8 * i));
    update(pad, padLen + 8);
    std::array<uint8_t, 16> out;
    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 4; j++) out[i * 4 + j] = (uint8_t)(state[i] >> (8 * j));
    reset();
    return out;
}

std::string MD5::hexDigest() {
    static const char* hex = "0123456789abcdef";
    std::string s;
    for (uint8_t b : digest()) {
        s += hex[b >> 4];
        s += hex[b & 15];
    }
    return s;
}

}  // namespace opsu
